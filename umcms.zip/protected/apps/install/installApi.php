<?php
class installApi extends baseApi{
	public function ifexist(){
		return true;
    } 
}