<?php 
return array (
  'APP_STATE' => 1,
  'APP_NAME' => 'UMCMS安装向导',
  'APP_VER' => '1.0.2012.0820',
  'APP_AUTHOR' => '邨小弍',
  'APP_ORIGINAL_PREFIX' => 'um_',
  'APP_TABLES' => '',
  'title' => 'UMMS安装向导',
  'rw_files' => 
  array (
    0 => 'protected/config.php',
    1 => 'protected/cache/',
    2 => 'protected/apps/install/',
  ),
  'run_after_del' => false,
  'APP' => 
  array (
    'HTML_CACHE_ON' => false,
  ),
  'TPL' => 
  array (
    'TPL_CACHE_ON' => false,
  ),
  'DB' => 
  array (
    'DB_CACHE_ON' => false,
  ),
);