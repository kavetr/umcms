<?php return array (
  'name' => 'VIP模板一',
  'author' => '邨小弍',
); ?> 