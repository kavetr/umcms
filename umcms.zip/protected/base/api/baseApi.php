<?php
class baseApi extends api{
}