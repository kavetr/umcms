<?php if(!defined('APP_NAME')) exit;?>
<div class="install_right">
  <div class="install_box">
<h2>安装状态。</h2>
安装成功，<a href="__ROOT__/">点击进入前台</a><br>
安装成功，<a href="{url('admin/index/index')}">点击进入后台</a>
  </div>
  
  <div class="clear"></div>
<div class="install_btn"><input class="button" value="完成" type="button" onClick="window.location.href = '__ROOT__/'"></div>
</div>