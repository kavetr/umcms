<?php 
return array (
  'APP_STATE' => 1,
  'APP_NAME' => '数据采集',
  'APP_VER' => '1.0.2015.0803',
  'APP_AUTHOR' => '邨小弍',
  'APP_ORIGINAL_PREFIX' => 'um_',
  'APP_TABLES' => 'collectrules',
);