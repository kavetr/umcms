<?php 
return array (
  'APP_STATE' => 1,
  'APP_NAME' => '默认前台',
  'APP_VER' => '1.0',
  'APP_AUTHOR' => '路过',
  'APP_ORIGINAL_PREFIX' => 'yx_',
  'APP_TABLES' => '',
  'TPL' => 
  array (
    'TPL_TEMPLATE_PATH' => 'mobile',
    'TPL_TEMPLATE_PATH_MOBILE' => 'mobile',
  ),
);